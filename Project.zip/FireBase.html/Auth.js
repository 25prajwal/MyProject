// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBdq1YyoNK5FNzqKRdVQL3zs2e7eII7TZA",
  authDomain: "prajwal-web.firebaseapp.com",
  databaseURL: "https://prajwal-web-default-rtdb.firebaseio.com",
  projectId: "prajwal-web",
  storageBucket: "prajwal-web.appspot.com",
  messagingSenderId: "997590417136",
  appId: "1:997590417136:web:948b82a0001f077f0d0c35",
  measurementId: "G-W2SR7J2YSY"
};

firebase.initializeApp(firebaseConfig);
